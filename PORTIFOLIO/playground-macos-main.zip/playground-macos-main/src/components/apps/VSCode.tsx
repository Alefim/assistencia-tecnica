export default function VSCode() {
  return (
    <iframe
      className="size-full bg-[#202020]"
      src="https://github1s.com/Renovamen/playground-macos/blob/main/README.md"
      title="VSCode"
    />
  );
}
