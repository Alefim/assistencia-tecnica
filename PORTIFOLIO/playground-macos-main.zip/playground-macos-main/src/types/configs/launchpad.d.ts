export interface LaunchpadData {
  id: string;
  title: string;
  img: string;
  link: string;
}
