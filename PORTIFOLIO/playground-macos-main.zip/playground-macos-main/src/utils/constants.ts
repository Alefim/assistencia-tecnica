export const minMarginY = 32; // top bar height
export const minMarginX = 100;
export const appBarHeight = 24; // app window's title bar height
