import type { UserData } from "~/types";

const user: UserData = {
  name: "Xiaohan Zou",
  avatar: "img/ui/avatar.jpg",
  password: ""
};

export default user;
